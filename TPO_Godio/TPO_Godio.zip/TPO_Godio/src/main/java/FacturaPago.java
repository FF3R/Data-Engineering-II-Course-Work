public class FacturaPago {
    private Integer id;
    private Integer pedidoId;
    private String formaPago;
    private Double monto;
}
