public class Productos {
    private String nombre;
    private Integer id;
    private String descripcion;
    private Integer stock;
    private Double precio;
    private Integer version;
}
