public class PrecioActualizado {
    private Integer idProducto;
    private Double precio;
}
