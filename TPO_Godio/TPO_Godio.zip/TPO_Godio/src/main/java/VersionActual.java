public class VersionActual {
    private Integer id;
    private Integer version;
}
