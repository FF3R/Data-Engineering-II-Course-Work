import java.time.LocalDateTime;

public class FacturaPagoControl {
    private Integer id;
    private Integer pedidoId;
    private Integer usuarioId;
    private String formaPago;
    private LocalDateTime fecha;
    private Double monto;
    private String operadorIntervinente;

}
