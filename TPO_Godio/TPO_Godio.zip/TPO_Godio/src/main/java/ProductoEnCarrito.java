public class ProductoEnCarrito {
    private Integer carritoId;
    private Integer productoId;
    private Integer cantidad;

}
