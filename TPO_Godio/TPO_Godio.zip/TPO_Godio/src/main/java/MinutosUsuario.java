public class MinutosUsuario {
    private Integer idUsuario;
    private Integer minutos;
}
