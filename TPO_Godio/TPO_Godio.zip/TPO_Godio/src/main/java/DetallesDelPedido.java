public class DetallesDelPedido {
    private Integer pedidoId;
    private Integer productoId;
    private Integer cantidad;
    private Double descuento;
    private String nombre;
    private String apellido;
    private String direccion;
    private Double ivaProductos;
    private Integer monto;
}
