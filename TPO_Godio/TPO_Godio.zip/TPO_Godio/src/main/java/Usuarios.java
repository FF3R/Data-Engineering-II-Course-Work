public class Usuarios {
    private Integer id;
    private String nombre;
    private String direccion;
    private String documentoIdentidad;
    private Integer minutosAlDia;
    private String tipoUsuario;
}
